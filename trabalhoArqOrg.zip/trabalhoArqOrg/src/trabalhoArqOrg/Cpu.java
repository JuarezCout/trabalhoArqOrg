package trabalhoArqOrg;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cpu implements Runnable {
	public int[] comando = new int[4], end = new int[3];
	private int regA = -1, regB = -1, regC = -1, regD = -1, regCI = 0, marcaLoop = 0;
	boolean procComando = false, temInstrucao = false, controleCPULer, controleCPUGravar, temDadosParaProcessar, gravarResultado;
	
	public Cpu() {
		
	}
	
	@Override
	public void run() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException ex) {
			 Logger.getLogger(EntradaSaida.class.getName()).log(Level.SEVERE, null, ex);
		}
		
		if (controleCPULer){ // manda sinal de que que ler para RAM
			if(Gerenciador.barr.isBarramentoContLivre()){
            	Gerenciador.barr.barramentoControle("RAM", "CPU", 3); 
            	System.out.println("CPU: Mandei controle para RAM pedindo o comando " + this.regCI);
            	Gerenciador.barr.setBarramentoContLivre(false);
            	Gerenciador.barr.setBarramentoEndLivre(true);        	
        	}		
		}
		
		if(temDadosParaProcessar){
			int[] comandoParaProcessar = new int[4];

			if(Gerenciador.barr.getFilaDad(0) != null){
				comandoParaProcessar = Gerenciador.barr.getFilaDad(0);
			}
			procComando(comandoParaProcessar);
			this.temDadosParaProcessar = false;
			
		}
		
		if(controleCPUGravar){
			//Fluxo para salvar os comandos processados
			if (Gerenciador.barr.isBarramentoContLivre()){
				Gerenciador.barr.barramentoControle("RAM", "CPU", 2); 
				Gerenciador.barr.setBarramentoContLivre(false);
            	Gerenciador.barr.setBarramentoEndLivre(true);            	
		}
		
	/*	if(gravarResultado){
			
				int[] posicaoComando;
				
				if (Gerenciador.barr.getFilaEnd() != null) {
					 System.out.println("ES: Recebi o endere�o da RAM");
					 posicaoComando = Gerenciador.barr.getFilaEnd();
					 Gerenciador.barr.setNullFilaEnd();
				} else {
					posicaoComando = null;
				}	          
	            
	            if (posicaoComando != null && posicaoComando[1] == 2){            	
	            	
					int[] enderecoParaPegarDado = {-1, -1, -1, posicaoComando[0]};					
	            }
				int[] comandoCpu = new int[4];
				//verifica se tem dados no barramento e salva num variavel local
				if (Gerenciador.barr.getFilaDadSize() != 0) {
					comandoCpu = Gerenciador.barr.getFilaDad(posicaoComando);
					System.out.println("CPU: recebi dados da RAM");
				} else {
					comandoCpu = null;
				}
				
				procComando(comandoCpu);
				this.regCI++;
			}*/
		}
		
	}
	
	//Metodos para processar os comandos
	private void procMov(int [] comando){
		int val1 = comando [1];
		int val2 = comando [2];
		
		switch (val2){
		case -2:
			val2 = this.regA;
			break;
		case -3:
			val2 = this.regB;
			break;
		case -4:
			val2 = this.regC;
			break;
		case -5:
			val2 = this.regD;
			break;
		default: 
			break;
		}		
		
		
		if(val1 < -1){
			switch (val1){
			case -2:
				this.regA  = val2;
				break;
			case -3:
				this.regB  = val2;
				break;
			case -4:
				this.regC  = val2;
				break;
			case -5:
				this.regD  = val2;
				break;
			default:
				int pos = (val1* -1) - 6 + Gerenciador.memoriaRam.getMemoriaSize()/2;
				this.end[0] = pos;
				this.end[1] = val2;
				this.end[2] = 2;
			}
		}
		this.controleCPUGravar = true;
	}
	
	private void procAdd(int [] comando){
		int val1 = comando [1];
		int val2 = comando [2];
		
		switch (val2){
		case -2:
			val2 = this.regA;
			break;
		case -3:
			val2 = this.regB;
			break;
		case -4:
			val2 = this.regC;
			break;
		case -5:
			val2 = this.regD;
			break;
		default: 
			break;
		}		
		
		
		if(val1 < -1){
			switch (val1){
			case -2:
				this.regA  += val2;
				break;
			case -3:
				this.regB  += val2;
				break;
			case -4:
				this.regC  += val2;
				break;
			case -5:
				this.regD  += val2;
				break;
			default:
				int pos = (val1* -1) - 6 + Gerenciador.memoriaRam.getMemoriaSize()/2;
				this.end[0] = pos;
				this.end[1] = val2;
				this.end[2] = 1;
			}
		}
		this.controleCPUGravar = true;
	}
	
	private void procImul(int [] comando){
		int val1 = comando [1];
		int val2 = comando [2];
		
		switch (val2){
		case -2:
			val2 = this.regA;
			break;
		case -3:
			val2 = this.regB;
			break;
		case -4:
			val2 = this.regC;
			break;
		case -5:
			val2 = this.regD;
			break;
		default: 
			break;
		}		
		
		
		if(val1 < -1){
			switch (val1){
			case -2:
				this.regA  *= val2;
				break;
			case -3:
				this.regB  *= val2;
				break;
			case -4:
				this.regC  *= val2;
				break;
			case -5:
				this.regD  *= val2;
				break;
			default:
				int pos = (val1* -1) - 6 + Gerenciador.memoriaRam.getMemoriaSize()/2;
				this.end[0] = pos;
				this.end[1] = val2;
				this.end[2] = 3;
			}
		}
		this.controleCPUGravar = true;
	}
	
	private void procInc(int [] comando){
		int val1 = comando [1];	
		if(val1 < -1){
			switch (val1){
			case -2:
				this.regA++;
				break;
			case -3:
				this.regB++;
				break;
			case -4:
				this.regC++;
				break;
			case -5:
				this.regD++;
				break;
			default:
				int pos = (val1* -1) - 6 + Gerenciador.memoriaRam.getMemoriaSize()/2;
				this.end[0] = pos;
				this.end[1] = val1;
				this.end[2] = 4 ;
			}
		}
		this.controleCPUGravar = true;
	}
	
	private void procComando(int [] comando){
		switch (comando[0]){
			case 1:
				procMov(comando);
				break;
			case 2:	
				procAdd(comando);
				break;
			case 3:
				procImul(comando);
				break;
			case 4:
				procInc(comando);
				break;
		}
	}

	/**
	 * @return the procComando
	 */
	public boolean isProcComando() {
		return procComando;
	}
	/**
	 * @param procComando the procComando to set
	 */
	public void setProcComando(boolean procComando) {
		this.procComando = procComando;
	}
	
	public void defineCI(int cont){
		regCI = cont;
	}
	/**
	 * @param temInstrucao the temInstrucao to set
	 */
	public void setTemInstrucao(boolean temInstrucao) {
		this.temInstrucao = temInstrucao;
	}

	/**
	 * @return the regCI
	 */
	public int getRegCI() {
		return regCI;
	}

	/**
	 * @param temDadosParaProcessar the temDadosParaProcessar to set
	 */
	public void setTemDadosParaProcessar(boolean temDadosParaProcessar) {
		this.temDadosParaProcessar = temDadosParaProcessar;
	}

	
	
}
