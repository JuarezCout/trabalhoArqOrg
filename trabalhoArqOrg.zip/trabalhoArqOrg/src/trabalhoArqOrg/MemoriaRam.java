package trabalhoArqOrg;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MemoriaRam implements Runnable {
	
	public int[] memoria;
	private int filaControle, contadorCpu;
	public int posMemoria = 0;
	public boolean temDados = false, comCPU, comES;
	
	public MemoriaRam(int tam){
		memoria = new int[tam];
		for (int i = 0; i < this.memoria.length; i++) {
			this.memoria[i] = -1;
		}
		System.out.println(memoria.length/2);
	}
	
	@Override
	public void run() {		
		while (true){
			
			try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(EntradaSaida.class.getName()).log(Level.SEVERE, null, ex);
            }
			
			if (comCPU) {
				int[] comando = new int[4];
				List<int[]> filaDadosParaCPU = new ArrayList<int[]>();
				if(Gerenciador.barr.isBarramentoDadLivre()){
					System.out.println("RAM: Recebi sinal da CPU");
					filaControle = Gerenciador.barr.getFilaCont(0);
					Gerenciador.barr.setNullFilaCont();
				} else {
					this.filaControle = 0;
				}	
				if (filaControle != 0 && filaControle == 2){
					this.contadorCpu = Gerenciador.cpu.getRegCI();
					for (int i = 0; i < 4; i++) {
						comando[i] = memoria[contadorCpu + i];
					}
					filaDadosParaCPU.add(comando);
					Gerenciador.barr.barramentoDados("CPU", filaDadosParaCPU, null); // manda para a CPU
					System.out.println("ES: Mandei dados para RAM");					
					Gerenciador.barr.setBarramentoDadLivre(false); // Ocupa o barramento de dados
					Gerenciador.barr.setBarramentoContLivre(true);
					Gerenciador.cpu.setTemDadosParaProcessar(true);
					
					filaDadosParaCPU.clear();
				}
			}
			
			if(comES){
				
				if(Gerenciador.barr.isBarramentoEndLivre()){
				//verifica se tem sinal de controle no barramento 
					if (Gerenciador.barr.getFilaCont(0) == 1){
						System.out.println("RAM: recebi sinal da ES");
						filaControle = Gerenciador.barr.getFilaCont(0);
						Gerenciador.barr.setNullFilaCont();
					} else {
						this.filaControle = 0;
					}
					
					//manda endere�o para quem mandou o sinal
					if (filaControle != 0 && filaControle == 1){ //se o sinal � da e/s
						this.posMemoria = posMemoriaDisponivel();
						Gerenciador.barr.barramentoEndereco("E/A", posMemoria);
						System.out.println("RAM: Mandei endere�o para EntradaSaida");
						this.filaControle = 0;
						Gerenciador.barr.setBarramentoEndLivre(false); // ocupa o barramento de endere�o
					}
				}
			}
				
			if(temDados){
				List<int[]> filaDadosRam = new ArrayList<int[]>();
				//verifica se tem dados no barramento e salva num variavel local
				if (Gerenciador.barr.getFilaDadSize() != 0) {
					for (int i = 0; i < Gerenciador.barr.getFilaDadSize(); i++) {
						filaDadosRam.add(Gerenciador.barr.getFilaDad(i));
					}
					//filaDadosRam = Gerenciador.barr.getFilaDad();
					System.out.println("RAM: recebi dados da ES");
				} else {
					filaDadosRam = null;
				}
	
				// grava na memoria os dados recebidos
				if (filaDadosRam != null) {
					this.posMemoria = filaDadosRam.get(0)[3];
					for (int i = 1; i < filaDadosRam.size(); i++) {
						addMemoria(filaDadosRam.get(i), posMemoria);	
					}
					filaDadosRam.clear();
					Gerenciador.barr.setNullFilaDad();
					System.out.println("RAM: Salvei os dados na memoria");
	
					for (int i = 0; i < memoria.length; i++) {
						if (i%40 == 0){System.out.println();}
						System.out.print(memoria[i] + " |");
					}
					System.out.println("\n\n");
				}
				this.temDados = false;
				//Gerenciador.cpu.setTemInstrucao(true);
			}
				//Gerenciador.barr.setBarramentoContLivre(false); // libera o barramento de Controle
			
		}
	}

	
	/**
	 * @param barramentoDadLivre the barramentoDadLivre to set
	 */
	public void setTemDados(boolean temDados) {
		this.temDados= temDados;
	}

	/**
	* Metodos para tratar sobre o recebimento e verifica��o da memoria
	*/
	
	public int posMemoriaDisponivel(){
		int cont = 0;
		while (memoria[cont] != -1){
			if (cont >= (memoria.length/2) - 4){  
				cont = 0;
				esvaziaMemoria(cont); 
				break;
			}
			if (memoria[cont] == -1 && (memoria[cont + Gerenciador.barr.getInstrucoesPorLoop()*4] == -1 && memoria[cont + 4] == -1)){
				break;
			}
			cont+=4;
		}
		return cont;
	}
	
	public void avanPosMemoria(){
		this.posMemoria += 4;
		
		if (this.posMemoria == (memoria.length / 2)){
			this.posMemoria = 0;
		}
	}
	
	public void esvaziaMemoria(int cont){
		
		for (int i = 0; i < Gerenciador.barr.getInstrucoesPorLoop(); i++) {
			
			memoria[cont]     = -1;
			memoria[cont + 1] = -1;
			memoria[cont + 2] = -1;
			memoria[cont + 3] = -1;
			
			cont+=4;
		}
		
		
	}
	
	public void addMemoria(int [] comando, int endereco){
			memoria[endereco]     = comando[0];
			memoria[endereco + 1] = comando[1];
			memoria[endereco + 2] = comando[2];
			memoria[endereco + 3] = comando[3];
			
			avanPosMemoria();
	}

	/**
	 * @param comCPU the comCPU to set
	 */
	public void setComCPU(boolean comCPU) {
		this.comCPU = comCPU;
	}

	/**
	 * @param comES the comES to set
	 */
	public void setComES(boolean comES) {
		this.comES = comES;
	}

	/**
	 * @return the memoria
	 */
	public int getMemoria(int i) {
		return memoria[i];
	}
	
	public int getMemoriaSize() {
		return memoria.length;
	}
}
